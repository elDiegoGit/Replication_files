function [xss,kss,css,lss,rss, margutss, nu, xsi]=steadystateGHHb(beta,delta,alpha,nbar, gamma, epsilon)

ess=((1-nbar)*(1-gamma*(1-epsilon)))/epsilon*nbar;
nu= (1+ess)/ess;
theta=((1/alpha)*(1/beta-(1-delta)))^(1/(alpha-1));
wss=(1-alpha)*theta^alpha;
xsi=wss/(nu*nbar^(nu-1));
lss=nbar;
rss=(1-beta*(1-delta))/beta;
kss=theta*lss;
xss=delta*kss;
css= (kss^alpha)*lss^(1-alpha)-xss;
margutss=(css-xsi*lss^nu)^(-epsilon);

