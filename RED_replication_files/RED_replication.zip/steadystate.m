function [xss,kss,css,lss,rss, margutss]=steadystate(beta,delta,alpha,gamma, epsilon)

rss=(1-beta*(1-delta))/beta;

theta=((1/alpha)*(1/beta-(1-delta)))^(1/(alpha-1));
omega=(1-alpha)*gamma/(1-gamma)*theta^alpha;
lss=omega/(omega-delta*theta+theta^alpha);
css=omega*(1-lss);
kss=theta*lss;
xss=delta*kss;
margutss=gamma/css*(css^gamma*(1-lss)^(1-gamma))^(1-epsilon);