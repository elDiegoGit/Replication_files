%Impulse Responses Non-Stationary Model
clear

load oon 
load oobn
load oocn
hcero = zeros(50,9);


time=49;

gc_e_a=zeros(1,time+1);
for i=1:time+1;
    gc_e_a(1,i+1)=gc_e_a(1,i)+oo_.irfs.gc_e_a(1,i);
end
gc_e_a=gc_e_a(2:size(gc_e_a,2));

bgc_e_a=zeros(1,time+1);
for i=1:time+1;
    bgc_e_a(1,i+1)=bgc_e_a(1,i)+oo_b.irfs.gc_e_a(1,i);
end
bgc_e_a=bgc_e_a(2:size(bgc_e_a,2));

cgc_e_a=zeros(1,time+1);
for i=1:time+1;
    cgc_e_a(1,i+1)=cgc_e_a(1,i)+oo_c.irfs.gc_e_a(1,i);
end
cgc_e_a=cgc_e_a(2:size(cgc_e_a,2));




gcs_e_a=zeros(1,time+1);
for i=1:time+1;
    gcs_e_a(1,i+1)=gcs_e_a(1,i)+oo_.irfs.gcs_e_a(1,i);
end
gcs_e_a=gcs_e_a(2:size(gcs_e_a,2));

bgcs_e_a=zeros(1,time+1);
for i=1:time+1;
    bgcs_e_a(1,i+1)=bgcs_e_a(1,i)+oo_b.irfs.gcs_e_a(1,i);
end
bgcs_e_a=bgcs_e_a(2:size(bgcs_e_a,2));

cgcs_e_a=zeros(1,time+1);
for i=1:time+1;
    cgcs_e_a(1,i+1)=cgcs_e_a(1,i)+oo_c.irfs.gcs_e_a(1,i);
end
cgcs_e_a=cgcs_e_a(2:size(cgcs_e_a,2));


gy_e_a=zeros(1,time+1);
for i=1:time+1;
    gy_e_a(1,i+1)=gy_e_a(1,i)+oo_.irfs.gy_e_a(1,i);
end
gy_e_a=gy_e_a(2:size(gy_e_a,2));

bgy_e_a=zeros(1,time+1);
for i=1:time+1;
    bgy_e_a(1,i+1)=bgy_e_a(1,i)+oo_b.irfs.gy_e_a(1,i);
end
bgy_e_a=bgy_e_a(2:size(bgy_e_a,2));

cgy_e_a=zeros(1,time+1);
for i=1:time+1;
    cgy_e_a(1,i+1)=cgy_e_a(1,i)+oo_c.irfs.gy_e_a(1,i);
end
cgy_e_a=cgy_e_a(2:size(cgy_e_a,2));



gys_e_a=zeros(1,time+1);
for i=1:time+1;
    gys_e_a(1,i+1)=gys_e_a(1,i)+oo_.irfs.gys_e_a(1,i);
end
gys_e_a=gys_e_a(2:size(gys_e_a,2));

bgys_e_a=zeros(1,time+1);
for i=1:time+1;
    bgys_e_a(1,i+1)=bgys_e_a(1,i)+oo_b.irfs.gys_e_a(1,i);
end
bgys_e_a=bgys_e_a(2:size(bgys_e_a,2));

cgys_e_a=zeros(1,time+1);
for i=1:time+1;
    cgys_e_a(1,i+1)=cgys_e_a(1,i)+oo_c.irfs.gys_e_a(1,i);
end
cgys_e_a=cgys_e_a(2:size(cgys_e_a,2));


gx_e_a=zeros(1,time+1);
for i=1:time+1;
    gx_e_a(1,i+1)=gx_e_a(1,i)+oo_.irfs.gx_e_a(1,i);
end
gx_e_a=gx_e_a(2:size(gx_e_a,2));

bgx_e_a=zeros(1,time+1);
for i=1:time+1;
    bgx_e_a(1,i+1)=bgx_e_a(1,i)+oo_b.irfs.gx_e_a(1,i);
end
bgx_e_a=bgx_e_a(2:size(bgx_e_a,2));

cgx_e_a=zeros(1,time+1);
for i=1:time+1;
    cgx_e_a(1,i+1)=cgx_e_a(1,i)+oo_c.irfs.gx_e_a(1,i);
end
cgx_e_a=cgx_e_a(2:size(cgx_e_a,2));

gxs_e_a=zeros(1,time+1);
for i=1:time+1;
    gxs_e_a(1,i+1)=gxs_e_a(1,i)+oo_.irfs.gxs_e_a(1,i);
end
gxs_e_a=gxs_e_a(2:size(gxs_e_a,2));

bgxs_e_a=zeros(1,time+1);
for i=1:time+1;
    bgxs_e_a(1,i+1)=bgxs_e_a(1,i)+oo_b.irfs.gxs_e_a(1,i);
end
bgxs_e_a=bgxs_e_a(2:size(bgxs_e_a,2));

cgxs_e_a=zeros(1,time+1);
for i=1:time+1;
    cgxs_e_a(1,i+1)=cgxs_e_a(1,i)+oo_c.irfs.gxs_e_a(1,i);
end
cgxs_e_a=cgxs_e_a(2:size(cgxs_e_a,2));


a_e_a=zeros(1,time+1);
for i=1:time+1;
    a_e_a(1,i+1)=a_e_a(1,i)+oo_.irfs.a_e_a(1,i);
end
a_e_a=a_e_a(2:size(a_e_a,2));


ba_e_a=zeros(1,time+1);
for i=1:time+1;
    ba_e_a(1,i+1)=ba_e_a(1,i)+oo_b.irfs.a_e_a(1,i);
end
ba_e_a=ba_e_a(2:size(ba_e_a,2));


ca_e_a=zeros(1,time+1);
for i=1:time+1;
    ca_e_a(1,i+1)=ca_e_a(1,i)+oo_c.irfs.a_e_a(1,i);
end
ca_e_a=ca_e_a(2:size(ca_e_a,2));


as_e_a=zeros(1,time+1);
for i=1:time+1;
    as_e_a(1,i+1)=as_e_a(1,i)+oo_.irfs.as_e_a(1,i);
end
as_e_a=as_e_a(2:size(as_e_a,2));

bas_e_a=zeros(1,time+1);
for i=1:time+1;
    bas_e_a(1,i+1)=bas_e_a(1,i)+oo_b.irfs.as_e_a(1,i);
end
bas_e_a=bas_e_a(2:size(bas_e_a,2));

cas_e_a=zeros(1,time+1);
for i=1:time+1;
    cas_e_a(1,i+1)=cas_e_a(1,i)+oo_c.irfs.as_e_a(1,i);
end
cas_e_a=cas_e_a(2:size(cas_e_a,2));







figure;
%set(0,'DefaultAxesLineStyleOrder',{'','-',':',':','o-'});
set(0,'DefaultAxesColorOrder',[0, 0, 0; 0, 0, 1; 1, 0, 0; 0, 0, 0]);
set(0,'DefaultAxesLineWidth',1.0);
set(gca,'LineWidth',9.5);



in=1;
nimp=49;





subplot(4,4,1), plot(in:nimp,gy_e_a(1,in:nimp),in:nimp,bgy_e_a(1,in:nimp), in:nimp,cgy_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('Y (Domestic Absorption)');
legend('kappa=0.005','kappa=0.05','kappa=0.25',0);


subplot(4,4,2),plot(in:nimp,gc_e_a(1,in:nimp),in:nimp,bgc_e_a(1,in:nimp), in:nimp,cgc_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C');


subplot(4,4,3), plot(in:nimp,oo_.irfs.l_e_a(1,in:nimp),in:nimp,oo_b.irfs.l_e_a(1,in:nimp), in:nimp,oo_c.irfs.l_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('L');


subplot(4,4,4), plot(in:nimp,gx_e_a(1,in:nimp),in:nimp,bgx_e_a(1,in:nimp), in:nimp,cgx_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('X');

subplot(4,4,5),plot(in:nimp,a_e_a(1,in:nimp),in:nimp,ba_e_a(1,in:nimp), in:nimp,ca_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('A');

subplot(4,4,6),plot(in:nimp,oo_.irfs.ph_e_a(1,in:nimp),in:nimp,oo_b.irfs.ph_e_a(1,in:nimp),in:nimp,oo_c.irfs.ph_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PH');

subplot(4,4,7), plot(in:nimp,oo_.irfs.rer_e_a(1,in:nimp),in:nimp,oo_b.irfs.rer_e_a(1,in:nimp), in:nimp,oo_c.irfs.rer_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('RER');

subplot(4,4,8),plot(in:nimp,gys_e_a(1,in:nimp),in:nimp,bgys_e_a(1,in:nimp), in:nimp,cgys_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('Y*(Foreign Absoption)');

subplot(4,4,9),plot(in:nimp,gcs_e_a(1,in:nimp),in:nimp,bgcs_e_a(1,in:nimp), in:nimp,cgcs_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C*');

subplot(4,4,10),plot(in:nimp,oo_.irfs.ls_e_a(1,in:nimp),in:nimp,oo_b.irfs.ls_e_a(1,in:nimp),in:nimp,oo_c.irfs.ls_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('L*');

subplot(4,4,11),plot(in:nimp,gxs_e_a(1,in:nimp),in:nimp,bgxs_e_a(1,in:nimp), in:nimp,cgxs_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('X*');

subplot(4,4,12),plot(in:nimp,as_e_a(1,in:nimp),in:nimp,bas_e_a(1,in:nimp), in:nimp,cas_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('A*');

subplot(4,4,13),plot(in:nimp,oo_.irfs.pfs_e_a(1,in:nimp),in:nimp,oo_b.irfs.pfs_e_a(1,in:nimp),in:nimp,oo_c.irfs.pfs_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PFS');

subplot(4,4,14),plot(in:nimp,oo_.irfs.tot_e_a(1,in:nimp),in:nimp,oo_b.irfs.tot_e_a(1,in:nimp),in:nimp,oo_c.irfs.tot_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Terms of Trade (ph/pf)');





set(0,'DefaultAxesLineStyleOrder','remove');
set(0,'DefaultAxesColorOrder','remove');






gc_e_v=zeros(1,time+1);
for i=1:time+1;
    gc_e_v(1,i+1)=gc_e_v(1,i)+oo_.irfs.gc_e_v(1,i);
end
gc_e_v=gc_e_v(2:size(gc_e_v,2));

bgc_e_v=zeros(1,time+1);
for i=1:time+1;
    bgc_e_v(1,i+1)=bgc_e_v(1,i)+oo_b.irfs.gc_e_v(1,i);
end
bgc_e_v=bgc_e_v(2:size(bgc_e_v,2));

cgc_e_v=zeros(1,time+1);
for i=1:time+1;
    cgc_e_v(1,i+1)=cgc_e_v(1,i)+oo_c.irfs.gc_e_v(1,i);
end
cgc_e_v=cgc_e_v(2:size(cgc_e_v,2));




gcs_e_v=zeros(1,time+1);
for i=1:time+1;
    gcs_e_v(1,i+1)=gcs_e_v(1,i)+oo_.irfs.gcs_e_v(1,i);
end
gcs_e_v=gcs_e_v(2:size(gcs_e_v,2));

bgcs_e_v=zeros(1,time+1);
for i=1:time+1;
    bgcs_e_v(1,i+1)=bgcs_e_v(1,i)+oo_b.irfs.gcs_e_v(1,i);
end
bgcs_e_v=bgcs_e_v(2:size(bgcs_e_v,2));

cgcs_e_v=zeros(1,time+1);
for i=1:time+1;
    cgcs_e_v(1,i+1)=cgcs_e_v(1,i)+oo_c.irfs.gcs_e_v(1,i);
end
cgcs_e_v=cgcs_e_v(2:size(cgcs_e_v,2));


gy_e_v=zeros(1,time+1);
for i=1:time+1;
    gy_e_v(1,i+1)=gy_e_v(1,i)+oo_.irfs.gy_e_v(1,i);
end
gy_e_v=gy_e_v(2:size(gy_e_v,2));

bgy_e_v=zeros(1,time+1);
for i=1:time+1;
    bgy_e_v(1,i+1)=bgy_e_v(1,i)+oo_b.irfs.gy_e_v(1,i);
end
bgy_e_v=bgy_e_v(2:size(bgy_e_v,2));

cgy_e_v=zeros(1,time+1);
for i=1:time+1;
    cgy_e_v(1,i+1)=cgy_e_v(1,i)+oo_c.irfs.gy_e_v(1,i);
end
cgy_e_v=cgy_e_v(2:size(cgy_e_v,2));



gys_e_v=zeros(1,time+1);
for i=1:time+1;
    gys_e_v(1,i+1)=gys_e_v(1,i)+oo_.irfs.gys_e_v(1,i);
end
gys_e_v=gys_e_v(2:size(gys_e_v,2));

bgys_e_v=zeros(1,time+1);
for i=1:time+1;
    bgys_e_v(1,i+1)=bgys_e_v(1,i)+oo_b.irfs.gys_e_v(1,i);
end
bgys_e_v=bgys_e_v(2:size(bgys_e_v,2));

cgys_e_v=zeros(1,time+1);
for i=1:time+1;
    cgys_e_v(1,i+1)=cgys_e_v(1,i)+oo_c.irfs.gys_e_v(1,i);
end
cgys_e_v=cgys_e_v(2:size(cgys_e_v,2));


gx_e_v=zeros(1,time+1);
for i=1:time+1;
    gx_e_v(1,i+1)=gx_e_v(1,i)+oo_.irfs.gx_e_v(1,i);
end
gx_e_v=gx_e_v(2:size(gx_e_v,2));

bgx_e_v=zeros(1,time+1);
for i=1:time+1;
    bgx_e_v(1,i+1)=bgx_e_v(1,i)+oo_b.irfs.gx_e_v(1,i);
end
bgx_e_v=bgx_e_v(2:size(bgx_e_v,2));

cgx_e_v=zeros(1,time+1);
for i=1:time+1;
    cgx_e_v(1,i+1)=cgx_e_v(1,i)+oo_c.irfs.gx_e_v(1,i);
end
cgx_e_v=cgx_e_v(2:size(cgx_e_v,2));

gxs_e_v=zeros(1,time+1);
for i=1:time+1;
    gxs_e_v(1,i+1)=gxs_e_v(1,i)+oo_.irfs.gxs_e_v(1,i);
end
gxs_e_v=gxs_e_v(2:size(gxs_e_v,2));

bgxs_e_v=zeros(1,time+1);
for i=1:time+1;
    bgxs_e_v(1,i+1)=bgxs_e_v(1,i)+oo_b.irfs.gxs_e_v(1,i);
end
bgxs_e_v=bgxs_e_v(2:size(bgxs_e_v,2));

cgxs_e_v=zeros(1,time+1);
for i=1:time+1;
    cgxs_e_v(1,i+1)=cgxs_e_v(1,i)+oo_c.irfs.gxs_e_v(1,i);
end
cgxs_e_v=cgxs_e_v(2:size(cgxs_e_v,2));


v_e_v=zeros(1,time+1);
for i=1:time+1;
    v_e_v(1,i+1)=v_e_v(1,i)+oo_.irfs.v_e_v(1,i);
end
v_e_v=v_e_v(2:size(v_e_v,2));


bv_e_v=zeros(1,time+1);
for i=1:time+1;
    bv_e_v(1,i+1)=bv_e_v(1,i)+oo_b.irfs.v_e_v(1,i);
end
bv_e_v=bv_e_v(2:size(bv_e_v,2));


cv_e_v=zeros(1,time+1);
for i=1:time+1;
    cv_e_v(1,i+1)=cv_e_v(1,i)+oo_c.irfs.v_e_v(1,i);
end
cv_e_v=cv_e_v(2:size(cv_e_v,2));


vs_e_v=zeros(1,time+1);
for i=1:time+1;
    vs_e_v(1,i+1)=vs_e_v(1,i)+oo_.irfs.vs_e_v(1,i);
end
vs_e_v=vs_e_v(2:size(vs_e_v,2));

bvs_e_v=zeros(1,time+1);
for i=1:time+1;
    bvs_e_v(1,i+1)=bvs_e_v(1,i)+oo_b.irfs.vs_e_v(1,i);
end
bas_e_v=bvs_e_v(2:size(bvs_e_v,2));

cvs_e_v=zeros(1,time+1);
for i=1:time+1;
    cvs_e_v(1,i+1)=cvs_e_v(1,i)+oo_c.irfs.vs_e_v(1,i);
end
cvs_e_v=cvs_e_v(2:size(cvs_e_v,2));







figure;
%set(0,'DefaultAxesLineStyleOrder',{'-',':','o-'});
set(0,'DefaultAxesColorOrder',[0, 0, 0,; 0, 0, 1; 1, 0, 0; 0, 0, 0]);
set(0,'DefaultAxesLineWidth',1.0);
set(gca,'LineWidth',9.5);



in=1;
nimp=49;





subplot(4,4,1), plot(in:nimp,gy_e_v(1,in:nimp),in:nimp,bgy_e_v(1,in:nimp), in:nimp,cgy_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('Y (Domestic Absorption)');
legend('compl','nonadj','+util',0);


subplot(4,4,2),plot(in:nimp,gc_e_v(1,in:nimp),in:nimp,bgc_e_v(1,in:nimp), in:nimp,cgc_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C');


subplot(4,4,3), plot(in:nimp,oo_.irfs.l_e_v(1,in:nimp),in:nimp,oo_b.irfs.l_e_v(1,in:nimp), in:nimp,oo_c.irfs.l_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('L');


subplot(4,4,4), plot(in:nimp,gx_e_v(1,in:nimp),in:nimp,bgx_e_v(1,in:nimp), in:nimp,cgx_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('X');

subplot(4,4,5),plot(in:nimp,v_e_v(1,in:nimp),in:nimp,bv_e_v(1,in:nimp), in:nimp,cv_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('V');

subplot(4,4,6),plot(in:nimp,oo_.irfs.ph_e_v(1,in:nimp),in:nimp,oo_b.irfs.ph_e_v(1,in:nimp),in:nimp,oo_c.irfs.ph_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PH');

subplot(4,4,7), plot(in:nimp,oo_.irfs.rer_e_v(1,in:nimp),in:nimp,oo_b.irfs.rer_e_v(1,in:nimp), in:nimp,oo_c.irfs.rer_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('RER');

subplot(4,4,8),plot(in:nimp,gys_e_v(1,in:nimp),in:nimp,bgys_e_v(1,in:nimp), in:nimp,cgys_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('Y*(Foreign Absoption)');

subplot(4,4,9),plot(in:nimp,gcs_e_v(1,in:nimp),in:nimp,bgcs_e_v(1,in:nimp), in:nimp,cgcs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C*');

subplot(4,4,10),plot(in:nimp,oo_.irfs.ls_e_v(1,in:nimp),in:nimp,oo_b.irfs.ls_e_v(1,in:nimp),in:nimp,oo_c.irfs.ls_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('L*');

subplot(4,4,11),plot(in:nimp,gxs_e_v(1,in:nimp),in:nimp,bgxs_e_v(1,in:nimp), in:nimp,cgxs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('X*');

subplot(4,4,12),plot(in:nimp,vs_e_v(1,in:nimp),in:nimp,bvs_e_v(1,in:nimp), in:nimp,cvs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('V*');

subplot(4,4,13),plot(in:nimp,oo_.irfs.pfs_e_v(1,in:nimp),in:nimp,oo_b.irfs.pfs_e_v(1,in:nimp),in:nimp,oo_c.irfs.pfs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PFS');

subplot(4,4,14),plot(in:nimp,oo_.irfs.tot_e_v(1,in:nimp),in:nimp,oo_b.irfs.tot_e_v(1,in:nimp),in:nimp,oo_c.irfs.tot_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Terms of Trade (ph/pf)');





set(0,'DefaultAxesLineStyleOrder','remove');
set(0,'DefaultAxesColorOrder','remove');








