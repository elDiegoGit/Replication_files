clear 

load oo 
load oob
load ooc
hcero = zeros(50,9);


figure;
%set(0,'DefaultAxesLineStyleOrder',{'','-',':',':','o-'});
set(0,'DefaultAxesColorOrder',[0, 0, 0; 0, 0, 1; 1, 0, 0; 0, 0, 0]);
set(0,'DefaultAxesLineWidth',1.0);
set(gca,'LineWidth',3.5);



in=1;
nimp=50;





subplot(4,4,1),plot(in:nimp,oo_.irfs.y_e_a(1,in:nimp),in:nimp,oo_b.irfs.y_e_a(1,in:nimp), in:nimp,oo_c.irfs.y_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1));
xlabel('Y (Domestic Absorption)');
legend('NUR','NO NUR','NO NUR+CU',0);


subplot(4,4,2),plot(in:nimp,oo_.irfs.c_e_a(1,in:nimp),in:nimp,oo_b.irfs.c_e_a(1,in:nimp), in:nimp,oo_c.irfs.c_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C');


subplot(4,4,3), plot(in:nimp,oo_.irfs.l_e_a(1,in:nimp),in:nimp,oo_b.irfs.l_e_a(1,in:nimp), in:nimp,oo_c.irfs.l_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('L');


subplot(4,4,4), plot(in:nimp,oo_.irfs.x_e_a(1,in:nimp),in:nimp,oo_b.irfs.x_e_a(1,in:nimp), in:nimp,oo_c.irfs.x_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('X');

subplot(4,4,5),plot(in:nimp,oo_.irfs.a_e_a(1,in:nimp),in:nimp,oo_b.irfs.a_e_a(1,in:nimp),in:nimp,oo_c.irfs.a_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('A');

subplot(4,4,6),plot(in:nimp,oo_.irfs.ph_e_a(1,in:nimp),in:nimp,oo_b.irfs.ph_e_a(1,in:nimp),in:nimp,oo_c.irfs.ph_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PH');

subplot(4,4,7), plot(in:nimp,oo_.irfs.rer_e_a(1,in:nimp),in:nimp,oo_b.irfs.rer_e_a(1,in:nimp), in:nimp,oo_c.irfs.rer_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('RER');

subplot(4,4,8),plot(in:nimp,oo_.irfs.ys_e_a(1,in:nimp),in:nimp,oo_b.irfs.ys_e_a(1,in:nimp),in:nimp,oo_c.irfs.ys_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('Y*(Foreign Absoption)');

subplot(4,4,9),plot(in:nimp,oo_.irfs.cs_e_a(1,in:nimp),in:nimp,oo_b.irfs.cs_e_a(1,in:nimp),in:nimp,oo_c.irfs.cs_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C*');

subplot(4,4,10),plot(in:nimp,oo_.irfs.ls_e_a(1,in:nimp),in:nimp,oo_b.irfs.ls_e_a(1,in:nimp),in:nimp,oo_c.irfs.ls_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('L*');

subplot(4,4,11),plot(in:nimp,oo_.irfs.xs_e_a(1,in:nimp),in:nimp,oo_b.irfs.xs_e_a(1,in:nimp),in:nimp,oo_c.irfs.xs_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('X*');

subplot(4,4,12),plot(in:nimp,oo_.irfs.pfs_e_a(1,in:nimp),in:nimp,oo_b.irfs.pfs_e_a(1,in:nimp),in:nimp,oo_c.irfs.pfs_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PFS');

subplot(4,4,13),plot(in:nimp,oo_.irfs.tot_e_a(1,in:nimp),in:nimp,oo_b.irfs.tot_e_a(1,in:nimp),in:nimp,oo_c.irfs.tot_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Terms of Trade (ph/pf)');

subplot(4,4,14),plot(in:nimp,oo_.irfs.cr_e_a(1,in:nimp),in:nimp,oo_b.irfs.cr_e_a(1,in:nimp),in:nimp,oo_c.irfs.cr_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Relative Consumption c/c*');

subplot(4,4,15),plot(in:nimp,oo_.irfs.output_e_a(1,in:nimp),in:nimp,oo_b.irfs.output_e_a(1,in:nimp),in:nimp,oo_c.irfs.output_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Domestic Output');

subplot(4,4,16),plot(in:nimp,oo_.irfs.outputf_e_a(1,in:nimp),in:nimp,oo_b.irfs.outputf_e_a(1,in:nimp),in:nimp,oo_c.irfs.outputf_e_a(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Foreign Output');





set(0,'DefaultAxesLineStyleOrder','remove');
set(0,'DefaultAxesColorOrder','remove');


figure;
%set(0,'DefaultAxesLineStyleOrder',{'','-',':',':','o-'});
set(0,'DefaultAxesColorOrder',[0, 0, 0; 0, 0, 1; 1, 0, 0; 0, 0, 0]);
set(0,'DefaultAxesLineWidth',1.0);
set(gca,'LineWidth',3.5);



in=1;
nimp=50;





subplot(4,4,1),plot(in:nimp,oo_.irfs.y_e_v(1,in:nimp),in:nimp,oo_b.irfs.y_e_v(1,in:nimp), in:nimp,oo_c.irfs.y_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1));
xlabel('Y (Domestic Absorption)');
%legend('rho=0.90','rho=0.95','rho=0.999',0);
legend('NUR','NO NUR','NO NUR+CU',0);


subplot(4,4,2),plot(in:nimp,oo_.irfs.c_e_v(1,in:nimp),in:nimp,oo_b.irfs.c_e_v(1,in:nimp), in:nimp,oo_c.irfs.c_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C');


subplot(4,4,3), plot(in:nimp,oo_.irfs.l_e_v(1,in:nimp),in:nimp,oo_b.irfs.l_e_v(1,in:nimp), in:nimp,oo_c.irfs.l_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('L');


subplot(4,4,4), plot(in:nimp,oo_.irfs.x_e_v(1,in:nimp),in:nimp,oo_b.irfs.x_e_v(1,in:nimp), in:nimp,oo_c.irfs.x_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('X');

subplot(4,4,5),plot(in:nimp,oo_.irfs.v_e_v(1,in:nimp),in:nimp,oo_b.irfs.v_e_v(1,in:nimp),in:nimp,oo_c.irfs.v_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('V');

subplot(4,4,6),plot(in:nimp,oo_.irfs.ph_e_v(1,in:nimp),in:nimp,oo_b.irfs.ph_e_v(1,in:nimp),in:nimp,oo_c.irfs.ph_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PH');

subplot(4,4,7), plot(in:nimp,oo_.irfs.rer_e_v(1,in:nimp),in:nimp,oo_b.irfs.rer_e_v(1,in:nimp), in:nimp,oo_c.irfs.rer_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 
xlabel('RER');

subplot(4,4,8),plot(in:nimp,oo_.irfs.ys_e_v(1,in:nimp),in:nimp,oo_b.irfs.ys_e_v(1,in:nimp),in:nimp,oo_c.irfs.ys_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1));

xlabel('Y*(Foreign Absoption)');

subplot(4,4,9),plot(in:nimp,oo_.irfs.cs_e_v(1,in:nimp),in:nimp,oo_b.irfs.cs_e_v(1,in:nimp),in:nimp,oo_c.irfs.cs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('C*');

subplot(4,4,10),plot(in:nimp,oo_.irfs.ls_e_v(1,in:nimp),in:nimp,oo_b.irfs.ls_e_v(1,in:nimp),in:nimp,oo_c.irfs.ls_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('L*');

subplot(4,4,11),plot(in:nimp,oo_.irfs.xs_e_v(1,in:nimp),in:nimp,oo_b.irfs.xs_e_v(1,in:nimp),in:nimp,oo_c.irfs.xs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('X*');

subplot(4,4,12),plot(in:nimp,oo_.irfs.pfs_e_v(1,in:nimp),in:nimp,oo_b.irfs.pfs_e_v(1,in:nimp),in:nimp,oo_c.irfs.pfs_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('PFS');

subplot(4,4,13),plot(in:nimp,oo_.irfs.tot_e_v(1,in:nimp),in:nimp,oo_b.irfs.tot_e_v(1,in:nimp),in:nimp,oo_c.irfs.tot_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Terms of Trade (ph/pf)');

subplot(4,4,14),plot(in:nimp,oo_.irfs.cr_e_v(1,in:nimp),in:nimp,oo_b.irfs.cr_e_v(1,in:nimp),in:nimp,oo_c.irfs.cr_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Relative Consumption c/c*');

subplot(4,4,15),plot(in:nimp,oo_.irfs.output_e_v(1,in:nimp),in:nimp,oo_b.irfs.output_e_v(1,in:nimp),in:nimp,oo_c.irfs.output_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Domestic Output');

subplot(4,4,16),plot(in:nimp,oo_.irfs.outputf_e_v(1,in:nimp),in:nimp,oo_b.irfs.outputf_e_v(1,in:nimp),in:nimp,oo_c.irfs.outputf_e_v(1,in:nimp), in:nimp, hcero(in:nimp,1)); 

xlabel('Foreign Output');





set(0,'DefaultAxesLineStyleOrder','remove');
set(0,'DefaultAxesColorOrder','remove');



