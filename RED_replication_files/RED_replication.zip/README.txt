***************************************************************************************

Instructions to Replicate Mandelman, Rabanal, Rubio-Ramirez, Vilan (Review of Economic Dynamics, 2011)


******************MODEL REPLICATION********************************************


The model is derived in the EquationAppendix.pdf attached. Check equation numbers in the pdf and match them 
with those in the  codes described below.

NOTE: Make sure steadystate.m ; steadystateGHHb.m and hpf1.m (hp-filter code) are included in the matlab folder before running the files with Dynare 4.


1-Baseline IRBC Stationary Model

**********Run Model_invest_statph.mod, following the instructions below.

-Check displayed moments and correlations along empirical counterparts in Table 5 and 6.

-To Run the a baseline IRBC version with NO IST shocks, NO capital utilization and NO adjustment costs: 

Fix sigmv sigmvs=0, fix psi=0, activate lines 140 and 141 in the code (i.e. u=us=1) and desactivate lines 138 and 139. 

*To Generate a model with Near Unit Root: Activate the Inv specific shock, set psi=0.55, and fix rrhov at 0.999.
*To Generate a model with NO Near Unit Root: Set rrhov at 0.97.
*To Generate a mode with NO Near Unit Root and Capital Utilization: Activate capital utilization in lines 138 and 139.

2-Baseline Stationary IRBC with GHH preferences a la Raffo.

**********Run Model_invest_statGHH.mod (IMPORTANT: RAFFO's MODEL WORKS ONLY WITH DYNARE 3)

It includes psi=0.55; rrhov=0.999; and adjustment costs.

3-Impulse Responses

***Impulse Responses: Run model_invest_staphc.mod (IMPORTANT: Graph plotting only works with Dynare 4)

Select different specifications: 

NUR=fix rrhov at 0.999, NO NUR: fix rrhov at 0.97, NO NUR + Cap Utilization: Activitate lines for Capital Utilization.

Right after running each of them rename oo_ : as oo_; oo_b; and oo_c 
and save them as oo.mat; oob.mat, ooc.mat respectively.

Run flexshockc.m to plot Figure 3.(It also includes the impulse response for the TFP shock, not displayed in the paper). 

Stat.fig is the figure in the paper. 



*********************************************************************************************************************
*********************************Non Stationary model****************************************************************


***Run model_invest_nonstathb.mod (that includes de estimates of the new VECM for investment relative prices)

You can activate capital utilization or increase the IST variance to 2.42 times the TFP variance.

***Impulse Responses: model_invest_nonstatch.mod

Select different values, after running each of them with such different values rename oo_ as: oo_; oo_b; oo_c 

and save them as oon.mat; oobn.mat, oocn.mat respectively. 

One can Select different cases, e.g. without adj costs or endogenous capital utilization (as previously done in the stationary case) 

**Graphs

Run flexshocknonsd.m (Nonstat.fig is the figure in the paper)


To replicate THE GHH specification a la RAFFO

*****Run model_invest_nonstatGHHh.mod (IMPORTANT: RAFFO MODEL WORKS ONLY WITH DYNARE 3)

**************************************************************************************************************************
**************************** Calibration *********************************************************************************

We also send two eviews files with the data and the vecms models used to generate the calibration for the two vecm processes. The file
istredwebpage.wf1 shows how to estimate the vecm for the ist processes. the file tfpredwebpage.wf1 does the same for the tfp processes.





