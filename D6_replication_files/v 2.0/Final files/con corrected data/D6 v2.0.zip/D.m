function D = A(a)
global cr
 D = cr-(a^5+2*a^4+3*a^3+2*a^2+a)/(3+2*a^2+4*a);

